﻿/*
 * Sensing.c
 *
 * Created: 2018-11-05 오전 6:11:01
 *  Author: njg71
 */ 
#include "BackgroundSetting/INTset.h"