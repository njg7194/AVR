﻿/*
 * BluetoothSetting.h
 *
 * Created: 2018-11-03 오후 3:04:03
 *  Author: njg71
 */ 


#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_

#include <string.h>
#include "UARTsetting.h"

char BLTdiscrimination();
char whatDirection(const char* data_buffer);



#endif /* BLUETOOTHSETTING_H_ */